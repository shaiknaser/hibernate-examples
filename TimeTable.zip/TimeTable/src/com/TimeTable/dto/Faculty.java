package com.TimeTable.dto;
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the facultys database table.
 * 
 */
@Entity
@Table(name="facultys")
@NamedQuery(name="Faculty.findAll", query="SELECT f FROM Faculty f")
public class Faculty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String facultyId;

	private String facultyName;

	private int maxHourPerWeek;

	private int maxHoursPerDay;

	//bi-directional many-to-one association to Department
	@ManyToOne
	@JoinColumn(name="DeptId")
	private Department department;

	//bi-directional many-to-one association to Designation
	@ManyToOne
	@JoinColumn(name="DesignationCode")
	private Designation designation;

	

	public Faculty() {
	}

	public String getFacultyId() {
		return this.facultyId;
	}

	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}

	public String getFacultyName() {
		return this.facultyName;
	}

	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}

	public int getMaxHourPerWeek() {
		return this.maxHourPerWeek;
	}

	public void setMaxHourPerWeek(int maxHourPerWeek) {
		this.maxHourPerWeek = maxHourPerWeek;
	}

	public int getMaxHoursPerDay() {
		return this.maxHoursPerDay;
	}

	public void setMaxHoursPerDay(int maxHoursPerDay) {
		this.maxHoursPerDay = maxHoursPerDay;
	}

	public Department getDepartment() {
		return this.department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Designation getDesignation() {
		return this.designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	
}