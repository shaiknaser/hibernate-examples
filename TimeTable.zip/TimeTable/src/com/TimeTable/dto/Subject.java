package com.TimeTable.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the subjects database table.
 * 
 */
@Entity
@Table(name="subjects")
@NamedQuery(name="Subject.findAll", query="SELECT s FROM Subject s")
public class Subject implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String subCode;

	private int hoursPerPeriod;
	
	private String subjectTitle;

	public String getSubjectTitle() {
		return subjectTitle;
	}

	public void setSubjectTitle(String subjectTitle) {
		this.subjectTitle = subjectTitle;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String mode;

	private int periodPerWeek;

	private String semister;



	//bi-directional many-to-one association to Department
	@ManyToOne
	@JoinColumn(name="DeptId")
	private Department department;

	public Subject() {
	}

	public String getSubCode() {
		return this.subCode;
	}

	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}

	public int getHoursPerPeriod() {
		return this.hoursPerPeriod;
	}

	public void setHoursPerPeriod(int hoursPerPeriod) {
		this.hoursPerPeriod = hoursPerPeriod;
	}

	public String getMode() {
		return this.mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getPeriodPerWeek() {
		return this.periodPerWeek;
	}

	public void setPeriodPerWeek(int periodPerWeek) {
		this.periodPerWeek = periodPerWeek;
	}

	public String getSemister() {
		return this.semister;
	}

	public void setSemister(String semister) {
		this.semister = semister;
	}

	

	

	public Department getDepartment() {
		return this.department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

}