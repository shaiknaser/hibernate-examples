package com.TimeTable.dto;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the logindata database table.
 * 
 */
@Entity
@NamedQuery(name="Logindata.findAll", query="SELECT l FROM Logindata l")
public class Logindata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String loginid;

	private String password;

	private String role;

	public Logindata() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLoginid() {
		return this.loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}