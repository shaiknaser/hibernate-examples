package com.TimeTable.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the departments database table.
 * 
 */
@Entity
@Table(name="departments")
@NamedQuery(name="Department.findAll", query="SELECT d FROM Department d")
public class Department implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String deptId;

	private String deptTitle;

	//bi-directional many-to-one association to Faculty
	@OneToMany(mappedBy="department")
	private List<Faculty> facultys;

	//bi-directional many-to-one association to Subject
	@OneToMany(mappedBy="department")
	private List<Subject> subjects;

	public Department() {
	}

	public String getDeptId() {
		return this.deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptTitle() {
		return this.deptTitle;
	}

	public void setDeptTitle(String deptTitle) {
		this.deptTitle = deptTitle;
	}

	public List<Faculty> getFacultys() {
		return this.facultys;
	}

	public void setFacultys(List<Faculty> facultys) {
		this.facultys = facultys;
	}

	public Faculty addFaculty(Faculty faculty) {
		getFacultys().add(faculty);
		faculty.setDepartment(this);

		return faculty;
	}

	public Faculty removeFaculty(Faculty faculty) {
		getFacultys().remove(faculty);
		faculty.setDepartment(null);

		return faculty;
	}

	public List<Subject> getSubjects() {
		return this.subjects;
	}

	public void setSubjects(List<Subject> subjects) {
		this.subjects = subjects;
	}

	public Subject addSubject(Subject subject) {
		getSubjects().add(subject);
		subject.setDepartment(this);

		return subject;
	}

	public Subject removeSubject(Subject subject) {
		getSubjects().remove(subject);
		subject.setDepartment(null);

		return subject;
	}

}