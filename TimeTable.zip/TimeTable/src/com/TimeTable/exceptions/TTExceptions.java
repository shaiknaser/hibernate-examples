package com.TimeTable.exceptions;

@SuppressWarnings("serial")
public class TTExceptions extends Exception{
	
	
	 
		public TTExceptions(String message)
		{super(message);
			
			
		}
	}



