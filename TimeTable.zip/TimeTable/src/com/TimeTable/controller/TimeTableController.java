package com.TimeTable.controller;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.TimeTable.dto.Department;
import com.TimeTable.dto.Designation;
import com.TimeTable.dto.Faculty;
import com.TimeTable.dto.Subject;
import com.TimeTable.exceptions.TTExceptions;
import com.TimeTable.service.ServiceInt;

@Controller
@Scope("session")
public class TimeTableController {
	Boolean flag = false;
	Boolean flag1 = false;
	@Autowired
	private ServiceInt serviceInt;

	public ServiceInt getPerService() {
		return serviceInt;
	}

	public void setPerService(ServiceInt ServiceInt) {
		this.serviceInt = ServiceInt;
	}

	@RequestMapping(value = "/loginCheck.html")
	public ModelAndView login(@RequestParam String[] credentials) {
		ModelAndView mv = new ModelAndView();
		try {
			String result = serviceInt.VerifyCredentials(credentials);
			if (result.equals("admin")) {
				System.out.println("in admin");
				mv.addObject("message", "Successfully logged in as admin ");
				mv.setViewName("LoginSuccess");
			}
			if (result.equals("user")) {
				System.out.println("in user");
				mv.addObject("message", "invalid credentials ");
				mv.setViewName("index");
			}
			if (result.equals("Invalid credentials")) {
				System.out.println("in error");
				mv.addObject("message", "invalid credentials ");
				mv.setViewName("index");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	// department code ---->

	@RequestMapping(value = "/DepartmentsList.html")
	public ModelAndView DepartmentsList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> resultlist = new ArrayList<>();
		try {
			resultlist = serviceInt.GetDepartmentList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("LoginSuccess");
			} else {
				mv.addObject("resultlist", resultlist);
				mv.setViewName("Result2");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditDept.html")
	public ModelAndView DepartmentsEdit(@RequestParam String deptId, @RequestParam String deptTitle) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("deptId", deptId);
		mv.addObject("deptTitle", deptTitle);
		mv.setViewName("EditDept");

		return mv;
	}

	@RequestMapping(value = "/SaveDept.html")
	public ModelAndView DepartmentsSave(@RequestParam String DeptId, @RequestParam String DeptName,
			@RequestParam String PreviousdeptId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			String result = serviceInt.UpdateDepartmentDetails(DeptId, DeptName, PreviousdeptId);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique DEpt ids");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("deptId", DeptId);
		mv.addObject("deptTitle", DeptName);
		mv.setViewName("EditDept");

		return mv;
	}

	@RequestMapping(value = "/DeleteDept.html")
	public ModelAndView DepartmentsDelete(@RequestParam String deptId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteDepartmentDetails(deptId);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addDept.html")
	public ModelAndView DepartmentsSave(@RequestParam String deptId, @RequestParam String DeptName) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveDepartmentDetails(deptId, DeptName);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique usernames");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("Result2");
		return mv;
	}

	// department code ends here ---->

	// Subjects code ---->

	@RequestMapping(value = "/SubjectsList.html")
	public ModelAndView SubjectssList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Subject> resultlist = new ArrayList<>();

		try {
			resultlist = serviceInt.GetSubjectsList();
			System.out.println(resultlist);

			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("LoginSuccess");
			} else {
				mv.addObject("resultlist", resultlist);
				ArrayList<Department> DepartmentList = new ArrayList<>();

				DepartmentList = serviceInt.GetDepartmentList();
				mv.addObject("DepartmentList", DepartmentList);
				mv.setViewName("Subjects");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditSubj.html")
	public ModelAndView SubjectssEdit(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek) throws TTExceptions {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> DepartmentList = new ArrayList<>();
		DepartmentList = serviceInt.GetDepartmentList();
		mv.addObject("deptId", deptId);
		mv.addObject("HourPerPeriod", HourPerPeriod);
		mv.addObject("SubCode", SubCode);
		mv.addObject("SubjectTitle", SubjectTitle);
		mv.addObject("Mode", Mode);
		mv.addObject("Semister", Semister);
		mv.addObject("PeriodPerWeek", PeriodPerWeek);
		mv.addObject("DepartmentList", DepartmentList);
		mv.setViewName("EditSubjects");

		return mv;
	}

	@RequestMapping(value = "/SaveSubj.html")
	public ModelAndView SubjectssSave(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek, @RequestParam String PreviousSubCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		Subject subject = new Subject();
		Department department = new Department();
		department.setDeptId(deptId);
		subject.setDepartment(department);

		subject.setHoursPerPeriod(Integer.parseInt(HourPerPeriod));
		subject.setMode(Mode);
		subject.setPeriodPerWeek(Integer.parseInt(PeriodPerWeek));
		subject.setSemister(Semister);
		subject.setSubCode(SubCode);
		subject.setSubjectTitle(SubjectTitle);
		System.out.println(subject);

		try {
			String result = serviceInt.UpdateSubjectDetails(subject, PreviousSubCode);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use Dept id as in Department Table");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject(subject);
		mv.setViewName("EditSubjects");

		return mv;
	}

	@RequestMapping(value = "/DeleteSubj.html")
	public ModelAndView SubjectssDelete(@RequestParam String SubCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteSubjectsDetails(SubCode);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
		} catch (TTExceptions e) {
		}

		return mv;
	}

	@RequestMapping(value = "/addSubjects.html")
	public ModelAndView SubjectssSave(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek) {

		ModelAndView mv = new ModelAndView();
		Subject subject = new Subject();
		Department department = new Department();
		department.setDeptId(deptId);
		subject.setDepartment(department);
		subject.setHoursPerPeriod(Integer.parseInt(HourPerPeriod));
		subject.setMode(Mode);
		subject.setPeriodPerWeek(Integer.parseInt(PeriodPerWeek));
		subject.setSemister(Semister);
		subject.setSubCode(SubCode);

		subject.setSubjectTitle(SubjectTitle);

		System.out.println(subject + "in inside the addsubjects method");

		try {
			String result = serviceInt.SaveSubjectsDetails(subject);

			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use Dept id as in Department Table");
			}
		} catch (TTExceptions e) {
			mv.setViewName("error");
		}
		mv.setViewName("Subjects");
		return mv;
	}

	// Subjects code ends here ---->
	// Designation code ---->

	@RequestMapping(value = "/DesignationsList.html")
	public ModelAndView DesignationsList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Designation> resultlist = new ArrayList<>();
		try {
			resultlist = serviceInt.GetDesignationList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("LoginSuccess");
			} else {
				mv.addObject("resultlist", resultlist);
				mv.setViewName("designationList");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditDesignation.html")
	public ModelAndView DesignationsEdit(@RequestParam String designationCode, @RequestParam String designation) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("designationCode", designationCode);
		mv.addObject("designation", designation);
		mv.setViewName("EditDesignation");

		return mv;
	}

	@RequestMapping(value = "/SaveDesignation.html")
	public ModelAndView DesignationSave(@RequestParam String designationCode, @RequestParam String Designation,
			@RequestParam String PreviousDesignationCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			System.out.println("inside beforee  dat" + designationCode + Designation + PreviousDesignationCode);
			String result = serviceInt.UpdateDesignationDetails(designationCode, Designation, PreviousDesignationCode);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique Designation Code");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("designationCode", designationCode);
		mv.addObject("designation", Designation);
		mv.setViewName("EditDesignation");

		return mv;
	}

	@RequestMapping(value = "/DeleteDesignation.html")
	public ModelAndView DesigantionsDelete(@RequestParam String designationCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteDesigantionDetails(designationCode);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addDesignation.html")
	public ModelAndView DesignationsSave(@RequestParam String designationCode, @RequestParam String designation) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveDesignationDetails(designationCode, designation);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique usernames");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("designationList");
		return mv;
	}

	// Designation code ends here ---->

	// Faculty code ---->

	@RequestMapping(value = "/FacultysList.html")
	public ModelAndView FacultysList() {
		ModelAndView mv = new ModelAndView();

		ArrayList<Faculty> resultlist = new ArrayList<>();
		try {
			ArrayList<Designation> designationList = new ArrayList<>();
			designationList = serviceInt.GetDesignationList();
			mv.addObject("designationList", designationList);
			ArrayList<Department> departmentlist = new ArrayList<>();
			departmentlist = serviceInt.GetDepartmentList();
			mv.addObject("departmentlist", departmentlist);
			resultlist = serviceInt.GetFacultyList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("facultyList");
			} else {

				mv.addObject("resultlist", resultlist);
				mv.setViewName("facultyList");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditFaculty.html")
	public ModelAndView FacultysEdit(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek) throws TTExceptions {
		ModelAndView mv = new ModelAndView();

		mv.addObject("facultyId", facultyId);
		mv.addObject("facultyName", facultyName);
		ArrayList<Designation> designationList = new ArrayList<>();
		designationList = serviceInt.GetDesignationList();
		mv.addObject("designationList", designationList);
		ArrayList<Department> departmentlist = new ArrayList<>();
		departmentlist = serviceInt.GetDepartmentList();
		mv.addObject("departmentlist", departmentlist);
		mv.addObject("maxHoursPerDay", maxHoursPerDay);
		mv.addObject("maxHoursPerWeek", maxHoursPerWeek);
		mv.setViewName("EditFaculty");

		return mv;
	}

	@RequestMapping(value = "/SaveFaculty.html")
	public ModelAndView DepartmentsSave(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek, @RequestParam String previousFacultyId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			String result = serviceInt.UpdateFacultyDetails(facultyId, facultyName, deptId, designationCode,
					maxHoursPerDay, maxHoursPerWeek, previousFacultyId);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique Faculty ids");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		mv.addObject("facultyId", facultyId);
		mv.addObject("facultyName", facultyName);
		mv.addObject("deptId", deptId);
		mv.addObject("designationCode", designationCode);
		mv.addObject("maxHoursPerDay", maxHoursPerDay);
		mv.addObject("maxHoursPerWeek", maxHoursPerWeek);
		mv.setViewName("EditFaculty");

		return mv;
	}

	@RequestMapping(value = "/DeleteFaculty.html")
	public ModelAndView FacultysDelete(@RequestParam String facultyId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteFacultyDetails(facultyId);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addFaculty.html")
	public ModelAndView FacultysSave(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveFacultyDetails(facultyId, facultyName, deptId, designationCode,
					maxHoursPerDay, maxHoursPerWeek);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique Faculty Id");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("facultyList");
		return mv;
	}

	// department code ends here ---->

	@RequestMapping(value = "/mapping.html")
	public ModelAndView mapping() throws TTExceptions {
		ModelAndView mv = new ModelAndView();
		ArrayList<Faculty> resultlist = new ArrayList<>();
		resultlist = serviceInt.GetFacultyList();
		ArrayList<Subject> resultlist1 = new ArrayList<>();
		resultlist1 = serviceInt.GetSubjectsList();
		mv.addObject("resultlist1", resultlist1);
		mv.addObject("resultlist", resultlist);
		mv.setViewName("mapping");
		return mv;
	}

	@RequestMapping(value = "/SaveMapData.html")
	public ModelAndView mapDataSaving(@RequestParam String facultyid, @RequestParam String[] subcode) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveMapData(facultyid, subcode);
			ArrayList<Faculty> resultlist = new ArrayList<>();
			resultlist = serviceInt.GetFacultyList();
			ArrayList<Subject> resultlist1 = new ArrayList<>();
			resultlist1 = serviceInt.GetSubjectsList();
			mv.addObject("resultlist1", resultlist1);
			mv.addObject("resultlist", resultlist);
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("message", "Successfully mapped the data for the FacultId" + facultyid);
		mv.setViewName("mapping");
		return mv;
	}

	// schedular code
	@RequestMapping(value = "/shedular.html")
	public ModelAndView Schedular() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> DepartmentList = new ArrayList<>();

		try {
			DepartmentList = serviceInt.GetDepartmentList();
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("DepartmentList", DepartmentList);
		mv.setViewName("schedular");
		return mv;
	}

	@RequestMapping(value = "/Getschedular.html")
	public ModelAndView getSchedular(@RequestParam String deptId, @RequestParam String sem) {
		ModelAndView mv = new ModelAndView();
		ArrayList<Subject> SubjectList = new ArrayList<>();
		try {
			SubjectList=serviceInt.GetSubjectsList(deptId,sem);
			HashMap<String, String[]> result=serviceInt.GetSchedularDetails(SubjectList);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

}
