package com.TimeTable.dto;
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the skills database table.
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name="skills")

public class Skill  {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	private  String facultyId;
	
	private String subCode;

	

	public String getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(String facultyId) {
		this.facultyId = facultyId;
	}

	public String getSubCode() {
		return subCode;
	}

	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}

	

	@Override
	public String toString() {
		return "Skill [facultyId=" + facultyId + ", subCode=" + subCode + "]";
	}
	
	
	
}