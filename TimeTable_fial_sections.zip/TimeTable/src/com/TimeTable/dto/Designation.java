package com.TimeTable.dto;
import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the designations database table.
 * 
 */
@Entity
@Table(name="designations")
@NamedQuery(name="Designation.findAll", query="SELECT d FROM Designation d")
public class Designation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String designationCode;

	private String designation;

	//bi-directional many-to-one association to Faculty
	@OneToMany(mappedBy="designation")
	private List<Faculty> facultys;

	public Designation() {
	}

	public String getDesignationCode() {
		return this.designationCode;
	}

	public void setDesignationCode(String designationCode) {
		this.designationCode = designationCode;
	}

	public List<Faculty> getFacultys() {
		return this.facultys;
	}

	public void setFacultys(List<Faculty> facultys) {
		this.facultys = facultys;
	}

	public Faculty addFaculty(Faculty faculty) {
		getFacultys().add(faculty);
		faculty.setDesignation(this);

		return faculty;
	}

	public Faculty removeFaculty(Faculty faculty) {
		getFacultys().remove(faculty);
		faculty.setDesignation(null);

		return faculty;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

}