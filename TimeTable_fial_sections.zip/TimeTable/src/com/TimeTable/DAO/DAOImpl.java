package com.TimeTable.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.TimeTable.dto.Department;
import com.TimeTable.dto.Designation;
import com.TimeTable.dto.Faculty;
import com.TimeTable.dto.Logindata;
import com.TimeTable.dto.Skill;
import com.TimeTable.dto.Subject;
import com.TimeTable.dto.TimeTable;
import com.TimeTable.exceptions.TTExceptions;

@Repository

public class DAOImpl implements DAOInt {

	@Autowired
	public SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public String VerifyCredentials(String[] credentials) throws TTExceptions {
		// TODO Auto-generated method stub
		Logindata loginDetails = new Logindata();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM Logindata where loginid=:id and password=:password");
			query.setParameter("id", credentials[0]);
			query.setParameter("password", credentials[1]);

			loginDetails = (Logindata) query.uniqueResult();
			if (query.uniqueResult() == null) {
				return "Invalid credentials";
			}
		} catch (Exception e) {
			System.out.println("in exception of login");
			System.out.println(e);
			return "SQL exception";
		}

		return loginDetails.getRole();
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Department> GetDepartmentList() throws TTExceptions {
		// TODO Auto-generated method stub
		ArrayList<Department> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM Department");

			resultlist = (ArrayList<Department>) query.list();
			System.out.println(resultlist.isEmpty());
		} catch (Exception e) {
			System.out.println("in exception of login");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;

	}

	@Override
	public String UpdateDepartmentDetails(String deptId, String deptTitle, String previousdeptId) throws TTExceptions {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.openSession();
			System.out.println("inside dao finish");
			Query query = session.createQuery(
					" update Department set DeptId=:deptId , DeptTitle=:deptTitle where DeptId=:previousdeptId");
			query.setParameter("deptId", deptId);
			query.setParameter("deptTitle", deptTitle);
			query.setParameter("previousdeptId", previousdeptId);

			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException e) {
			System.out.println("unique violation");
			return "unique violation";
		} catch (Exception e) {
			System.out.println("in exception of login");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return "success";
	}

	@Override
	public String DeleteDepartmentDetails(String deptId) throws TTExceptions {
		// TODO Auto-generated method stub

		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" delete from Department  where DeptId=:deptId ");
			query.setParameter("deptId", deptId);
			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException err) {
			return "Forein key in other Table";
		} catch (Exception e) {

			throw new TTExceptions(e.toString());
		}
		return "success";
	}

	@Override
	public String SaveDepartmentDetails(String deptId, String deptTitle) throws TTExceptions {
		// TODO Auto-generated method stub
		try {

			Session session = sessionFactory.openSession();
			Department departments = new Department();
			departments.setDeptId(deptId);
			departments.setDeptTitle(deptTitle);

			session.beginTransaction();
			session.save(departments);

			session.getTransaction().commit();
			session.close();
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}

		return "ADDED successfully";
	}

	// departments code ended
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Subject> GetSubjectsList() throws TTExceptions {
		ArrayList<Subject> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM Subject");

			resultlist = (ArrayList<Subject>) query.list();
			System.out.println(resultlist.isEmpty());
		} catch (Exception e) {
			System.out.println("in exception of login");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;

	}

	@Override
	public String UpdateSubjectDetails(Subject subject, String previousSubCode) throws TTExceptions {
		try {
			Session session = sessionFactory.openSession();
			System.out.println("inside dao finish");
			Query query = session.createQuery(
					" update Subject set DeptId=:deptId ,HoursPerPeriod=:HoursPerPeriod,Mode=:mode,PeriodPerWeek=:periodPerWeek,Semister=:semister,SubCode=:subcode,SubjectTitle=:subjectTitle where subcode=:previousSubCode");
			query.setParameter("deptId", subject.getDepartment());
			query.setParameter("HoursPerPeriod", subject.getHoursPerPeriod());
			query.setParameter("mode", subject.getMode());
			query.setParameter("periodPerWeek", subject.getPeriodPerWeek());
			query.setParameter("semister", subject.getSemister());
			query.setParameter("subcode", subject.getSubCode());
			query.setParameter("subjectTitle", subject.getSubjectTitle());

			query.setParameter("previousSubCode", previousSubCode);

			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException e) {
			System.out.println("unique violation");
			return "unique violation";
		} catch (Exception e) {
			System.out.println("in exception of login");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return "success";
	}

	@Override
	public String DeleteSubjectsDetails(String subCode) throws TTExceptions {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" delete from Subject  where SubCode=:subCode");
			query.setParameter("subCode", subCode);
			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException err) {
			return "Forein key in other Table";
		} catch (Exception e) {

			throw new TTExceptions(e.toString());
		}
		return "success";
	}

	@Override
	public String SaveSubjectsDetails(Subject subject) throws TTExceptions {
		// TODO Auto-generated method stub
		try {

			Session session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(subject);

			session.getTransaction().commit();
			session.close();
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}

		return "ADDED successfully";
	}

	// Designations code starts
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Designation> GetDesignationList() throws TTExceptions {
		// TODO Auto-generated method stub
		ArrayList<Designation> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM Designation");

			resultlist = (ArrayList<Designation>) query.list();
			System.out.println(resultlist.isEmpty());
		} catch (Exception e) {
			System.out.println("in exception of Designations list");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;
	}

	@Override
	public String UpdateDesignationDetails(String designationCode, String designation, String previousDesgnationCode)
			throws TTExceptions {
		// TODO Auto-generated method stub
		try {

			System.out.println(
					"inside dao finish" + designationCode + "     " + designation + "     " + previousDesgnationCode);
			DeleteDesigantionDetails(previousDesgnationCode);

			if (SaveDesignationDetails(designationCode, designation).equals("unique violation")) {
				return "unique violation";
			}

		} catch (org.hibernate.exception.ConstraintViolationException e) {
			System.out.println("unique violation");
			return "unique violation";
		} catch (Exception e) {
			System.out.println("in exception of UpdateDesignationDetails");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return "success";
	}

	@Override
	public String DeleteDesigantionDetails(String designationCode) throws TTExceptions {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" delete from Designation  where DesignationCode=:designationCode");
			query.setParameter("designationCode", designationCode);
			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException err) {
			return "Forein key in other Table";
		} catch (Exception e) {

			throw new TTExceptions(e.toString());
		}
		return "success";
	}

	@Override
	public String SaveDesignationDetails(String designationCode, String designation) throws TTExceptions {
		// TODO Auto-generated method stub
		try {

			Session session = sessionFactory.openSession();
			Designation designations = new Designation();
			designations.setDesignationCode(designationCode);
			designations.setDesignation(designation);

			session.beginTransaction();
			session.save(designations);

			session.getTransaction().commit();
			session.close();
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}

		return "ADDED successfully";
	}
	// Designations code ended

	// Facultys code Start

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Faculty> GetFacultyList() throws TTExceptions {

		ArrayList<Faculty> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM Faculty");

			resultlist = (ArrayList<Faculty>) query.list();
			System.out.println(resultlist.isEmpty());
		} catch (Exception e) {
			System.out.println("in exception of Facultys");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;
	}

	@Override
	public String UpdateFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek, String previousFacultyId) throws TTExceptions {
		try {

			Session session = sessionFactory.openSession();
			System.out.println("inside dao finish");
			Designation designations = new Designation();
			designations.setDesignationCode(designationCode);
			Department department = new Department();
			department.setDeptId(deptId);
			Faculty faculty = new Faculty();
			faculty.setDepartment(department);
			faculty.setDesignation(designations);
			faculty.setFacultyId(facultyId);
			faculty.setFacultyName(facultyName);
			faculty.setMaxHourPerWeek(maxHoursPerWeek);
			faculty.setMaxHoursPerDay(maxHoursPerDay);
			Skill skill = new Skill();
			DeleteFacultyDetails(previousFacultyId);

			if (SaveFacultyDetails(facultyId, facultyName, deptId, designationCode, maxHoursPerDay, maxHoursPerWeek)
					.equals("unique violation")) {
				System.out.println("inside the query");
				return "unique violation";
			}

		} catch (org.hibernate.exception.ConstraintViolationException e) {
			System.out.println("unique violation");
			return "unique violation";
		} catch (Exception e) {
			System.out.println("in exception of UpdateFacultyDetails");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return "success";
	}

	@Override
	public String DeleteFacultyDetails(String facultyId) throws TTExceptions {
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" delete from Faculty  where FacultyId=:facultyId ");
			query.setParameter("facultyId", facultyId);
			query.executeUpdate();

		} catch (org.hibernate.exception.ConstraintViolationException err) {
			return "Forein key in other Table";
		} catch (Exception e) {

			throw new TTExceptions(e.toString());
		}
		return "success";
	}

	@Override
	public String SaveFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek) throws TTExceptions {
		try {
			Department department = new Department();
			Designation designation = new Designation();
			department.setDeptId(deptId);
			designation.setDesignationCode(designationCode);
			Session session = sessionFactory.openSession();
			Faculty facultys = new Faculty();
			facultys.setFacultyId(facultyId);
			facultys.setFacultyName(facultyName);
			facultys.setDepartment(department);
			facultys.setDesignation(designation);
			facultys.setMaxHoursPerDay(maxHoursPerDay);
			facultys.setMaxHourPerWeek(maxHoursPerWeek);
			System.out.println(facultys);
			session.beginTransaction();
			session.save(facultys);

			session.getTransaction().commit();
			session.close();

		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}

		return "ADDED successfully";
	}
	// data display completed

	@Override
	public String SaveMapData(String facultyid, String[] subcode) throws TTExceptions {
		try {
			for (int i = 0; i < subcode.length; i++) {
				Skill skill = new Skill();
				skill.setFacultyId(facultyid);
				skill.setSubCode(subcode[i]);

				Session session = sessionFactory.openSession();
				session.beginTransaction();
				session.save(skill);

				session.getTransaction().commit();
				session.close();
			}
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}
		return null;
		// schedular work starts
	}

	@SuppressWarnings({ "unchecked", "null", "rawtypes" })
	@Override
	public HashMap<String, String[]> GetSchedularDetails(ArrayList<Subject> subjectList) throws TTExceptions {
		ArrayList<String[]> arrays=new ArrayList<>();
		HashMap<String, String[]> result = new HashMap<>();
		List<String> facultyId =  new ArrayList();
		
		@SuppressWarnings("unused")
		ArrayList<Skill> skillList = new ArrayList<>();
		for (Subject subject : subjectList) {
			try {
				Session session = sessionFactory.openSession();
					System.out.println("subject name is "+subject.getSubCode());
				Query query = session.createQuery(
						" Select facultyName from Faculty where facultyid in (SELECT Distinct facultyId  FROM Skill where subCode =:subCode)");
				query.setParameter("subCode", subject.getSubCode());
				
				List<String> rows = query.list();
				int i = 0;
				System.out.println(rows.get(0));
				for (i=0;i<rows.size();i++) {
				   
				   facultyId.add(rows.get(i));
				   System.out.println(" the size of row"+rows.size());
				    
				}
				i=0;
				System.out.println("----1----1");
				String [] faculty = facultyId.toArray(new String[facultyId.size()]);
				result.put(subject.getSubCode(), faculty);
				facultyId =  new ArrayList();

			} catch (Exception e) {
				System.out.println("in exception of get schedular list");
				System.out.println(e);
				return null;
			}

		}
		System.out.println(result);
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Subject> GetSubjectsList(String deptId, String sem) throws TTExceptions {
		ArrayList<Subject> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();
			Department dept = new Department();
			dept.setDeptId(deptId);
			Query query = session.createQuery(" FROM Subject where DeptId=:department and semister=:semister");
			query.setParameter("department", dept.getDeptId());
			query.setParameter("semister", sem);

			resultlist = (ArrayList<Subject>) query.list();

		} catch (Exception e) {
			System.out.println("in exception of get schedular list");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;
	}

		
		
	@Override
	public String saveTimeTable(String[][] timetable, String semister,String deptid,String section) throws TTExceptions {
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" delete from TimeTable  where semister=:semister and section=:section ");
			query.setParameter("semister", semister);
			query.setParameter("section", section);
			query.executeUpdate();
			
			for(int i=0;i<6;i++){
				
			TimeTable tt=new TimeTable();
			System.out.println(deptid);
				tt.setDay(i+1);
				tt.setPeriod1(timetable[i][0]);
				tt.setPeriod2(timetable[i][1]);
				tt.setPeriod3(timetable[i][2]);
				tt.setPeriod4(timetable[i][3]);
				tt.setPeriod5(timetable[i][4]);
				tt.setPeriod6(timetable[i][5]);
				tt.setPeriod7(timetable[i][6]);
				tt.setSemister(semister);
				tt.setDeptId(deptid);
				tt.setSection(section);
				
			
			
			Session session1 = sessionFactory.openSession();
			session1.beginTransaction();
			session1.save(tt);

			session1.getTransaction().commit();
			session1.close();
			}
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			return "unique violation";
		} catch (Exception e) {
			System.out.println("error is " + e);
			return "EXCEPTION";
		}

		return "ADDED successfully";
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<TimeTable> GetTimeTable(String sem, String deptId,String section) throws TTExceptions {
		ArrayList<TimeTable> resultlist = new ArrayList<>();
		try {
			Session session = sessionFactory.openSession();

			Query query = session.createQuery(" FROM TimeTable where semister=:semister and deptId=:deptId and section=:section");
			query.setParameter("deptId",deptId);
			query.setParameter("semister", sem);
			query.setParameter("section", section);
			resultlist = (ArrayList<TimeTable>) query.list();
			System.out.println(resultlist.isEmpty());
		} catch (Exception e) {
			System.out.println("in exception of Designations list");
			System.out.println(e);
			throw new TTExceptions(e.toString());
		}

		return resultlist;
	}
	

}
