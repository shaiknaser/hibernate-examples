package com.TimeTable.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.TimeTable.dto.Department;
import com.TimeTable.dto.Designation;
import com.TimeTable.dto.Faculty;
import com.TimeTable.dto.Subject;
import com.TimeTable.dto.TimeTable;
import com.TimeTable.exceptions.TTExceptions;

public interface ServiceInt {

	String VerifyCredentials(String[] credentials) throws TTExceptions;

	ArrayList<Department> GetDepartmentList()throws TTExceptions;

	String UpdateDepartmentDetails(String deptId, String deptTitle, String previousdeptId)throws TTExceptions;

	String DeleteDepartmentDetails(String deptId)throws TTExceptions;

	String SaveDepartmentDetails(String deptId, String deptName)throws TTExceptions;

	ArrayList<Subject> GetSubjectsList() throws TTExceptions;

	String UpdateSubjectDetails(Subject subject, String previousSubCode)throws TTExceptions;

	String DeleteSubjectsDetails(String subCode)throws TTExceptions;

	String SaveSubjectsDetails(Subject subject)throws TTExceptions;

	ArrayList<Designation> GetDesignationList()throws TTExceptions;

	String UpdateDesignationDetails(String designationCode, String designation, String previousDesgnationCode)throws TTExceptions;

	String DeleteDesigantionDetails(String designationCode)throws TTExceptions;

	String SaveDesignationDetails(String designationCode, String designation)throws TTExceptions;

	ArrayList<Faculty> GetFacultyList()throws TTExceptions;

	String UpdateFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek, String previousFacultyId)throws TTExceptions;

	String DeleteFacultyDetails(String facultyId)throws TTExceptions;

	String SaveFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek)throws TTExceptions;

	String SaveMapData(String facultyid, String[] subcode)throws TTExceptions;

	HashMap<String, String[]> GetSchedularDetails(ArrayList<Subject> subjectList)throws TTExceptions;

	ArrayList<Subject> GetSubjectsList(String deptId, String sem)throws TTExceptions;

	String saveTimeTable(String[][] timetable, String schedularSave, String deptIdGlobal, String string)throws TTExceptions;

	ArrayList<TimeTable> GetTimeTable(String sem, String deptId,String section)throws TTExceptions;
	
	
}
