package com.TimeTable.service;



import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TimeTable.DAO.DAOInt;
import com.TimeTable.dto.Department;
import com.TimeTable.dto.Designation;
import com.TimeTable.dto.Faculty;
import com.TimeTable.dto.Subject;
import com.TimeTable.dto.TimeTable;
import com.TimeTable.exceptions.TTExceptions;




@Service
public class ServiceImpl implements ServiceInt {

	@Autowired
	private DAOInt daoInt;

	public DAOInt getPerDAOInt() {
		return daoInt;
	}

	public void setPerDAOInt(DAOInt perDAOInt) {
		this.daoInt = perDAOInt;
	}

	@Override
	public String VerifyCredentials(String[] credentials) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.VerifyCredentials(credentials);
	}

	@Override
	public ArrayList<Department> GetDepartmentList() throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetDepartmentList();
	}

	@Override
	public String UpdateDepartmentDetails(String deptId, String deptTitle, String previousdeptId) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.UpdateDepartmentDetails(deptId, deptTitle, previousdeptId);	}

	@Override
	public String DeleteDepartmentDetails(String deptId) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.DeleteDepartmentDetails(deptId);
	}

	@Override
	public String SaveDepartmentDetails(String deptId, String deptName) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.SaveDepartmentDetails(deptId, deptName);
	}

	@Override
	public ArrayList<Subject> GetSubjectsList() throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetSubjectsList();
	}

	@Override
	public String UpdateSubjectDetails(Subject subject, String previousSubCode) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.UpdateSubjectDetails(subject, previousSubCode);
	}

	@Override
	public String DeleteSubjectsDetails(String subCode) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.DeleteSubjectsDetails(subCode);
	}

	@Override
	public String SaveSubjectsDetails(Subject subject) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.SaveSubjectsDetails(subject);
	}

	@Override
	public ArrayList<Designation> GetDesignationList() throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetDesignationList();
	}

	@Override
	public String UpdateDesignationDetails(String designationCode, String designation, String previousDesgnationCode)
			throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.UpdateDesignationDetails(designationCode, designation, previousDesgnationCode);	
	}

	@Override
	public String DeleteDesigantionDetails(String designationCode) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.DeleteDesigantionDetails(designationCode);
	}

	@Override
	public String SaveDesignationDetails(String designationCode, String designation) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.SaveDesignationDetails(designationCode, designation);
	}

	@Override
	public ArrayList<Faculty> GetFacultyList() throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetFacultyList();
	}

	@Override
	public String UpdateFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek, String previousFacultyId) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.UpdateFacultyDetails(facultyId, facultyName, deptId,designationCode,maxHoursPerDay,maxHoursPerWeek,previousFacultyId);
	}

	@Override
	public String DeleteFacultyDetails(String facultyId) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.DeleteFacultyDetails(facultyId);
	}

	@Override
	public String SaveFacultyDetails(String facultyId, String facultyName, String deptId, String designationCode,
			int maxHoursPerDay, int maxHoursPerWeek) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.SaveFacultyDetails(facultyId, facultyName, deptId,designationCode,maxHoursPerDay,maxHoursPerWeek);
	}

	@Override
	public String SaveMapData(String facultyid, String[] subcode) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.SaveMapData(facultyid, subcode);
	}

	

	@Override
	public ArrayList<Subject> GetSubjectsList(String deptId, String sem) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetSubjectsList(deptId, sem);
	}

	@Override
	public HashMap<String, String[]> GetSchedularDetails(ArrayList<Subject> subjectList) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetSchedularDetails(subjectList);
	}

	

	@Override
	public String saveTimeTable(String[][] timetable, String schedularSave,String s,String section) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.saveTimeTable(timetable,schedularSave,s,section);
	}

	@Override
	public ArrayList<TimeTable> GetTimeTable(String sem, String deptId,String section) throws TTExceptions {
		// TODO Auto-generated method stub
		return daoInt.GetTimeTable(sem, deptId,section);
	}

	
	
	

}
