package com.TimeTable.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.TimeTable.dto.Department;
import com.TimeTable.dto.Designation;
import com.TimeTable.dto.Faculty;
import com.TimeTable.dto.Subject;
import com.TimeTable.dto.TimeTable;
import com.TimeTable.exceptions.TTExceptions;
import com.TimeTable.service.ServiceInt;

@SuppressWarnings("serial")
@Controller
@Scope("session")
public class TimeTableController implements Serializable {
 int x = 1;
	Boolean flag = false;
	Boolean flag1 = false;
	Boolean flag2 = false;
	@Autowired
	private ServiceInt serviceInt;

	public ServiceInt getPerService() {
		return serviceInt;
	}

	public void setPerService(ServiceInt ServiceInt) {
		this.serviceInt = ServiceInt;
	}

	@RequestMapping(value = "/loginCheck.html")
	public ModelAndView login(@RequestParam String[] credentials) {
		ModelAndView mv = new ModelAndView();
		try {
			String result = serviceInt.VerifyCredentials(credentials);
			if (result.equals("admin")) {
				System.out.println("in admin");
				mv.addObject("message", "Successfully logged in as admin ");
				mv.setViewName("LoginSuccess");
			}
			if (result.equals("user")) {
				System.out.println("in user");
				mv.addObject("message", "invalid authorization ");
				mv.setViewName("index");
			}
			if (result.equals("Invalid credentials")) {
				System.out.println("in error");
				mv.addObject("message", "invalid credentials ");
				mv.setViewName("index");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	// department code ---->

	@RequestMapping(value = "/DepartmentsList.html")
	public ModelAndView DepartmentsList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> resultlist = new ArrayList<>();
		try {
			resultlist = serviceInt.GetDepartmentList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("DepartmentList");
			} else {
				mv.addObject("resultlist", resultlist);
				mv.setViewName("DepartmentList");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditDept.html")
	public ModelAndView DepartmentsEdit(@RequestParam String deptId, @RequestParam String deptTitle) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("deptId", deptId);
		mv.addObject("deptTitle1", deptTitle);
		mv.setViewName("EditDept");
		System.out.println(deptTitle + "deptartment name is ");
		return mv;
	}

	@RequestMapping(value = "/SaveDept.html")
	public ModelAndView DepartmentsSave(@RequestParam String DeptId, @RequestParam String DeptName,
			@RequestParam String PreviousdeptId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			String result = serviceInt.UpdateDepartmentDetails(DeptId, DeptName, PreviousdeptId);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique DEpt ids");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("deptId", DeptId);
		mv.addObject("deptTitle", DeptName);
		mv.setViewName("EditDept");

		return mv;
	}

	@RequestMapping(value = "/DeleteDept.html")
	public ModelAndView DepartmentsDelete(@RequestParam String deptId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteDepartmentDetails(deptId);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addDept.html")
	public ModelAndView DepartmentsSave(@RequestParam String deptId, @RequestParam String DeptName) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveDepartmentDetails(deptId, DeptName);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:DepartmentsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique department id's");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("Result2");
		return mv;
	}

	// department code ends here ---->

	// Subjects code ---->

	@RequestMapping(value = "/SubjectsList.html")
	public ModelAndView SubjectssList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Subject> resultlist = new ArrayList<>();

		try {
			resultlist = serviceInt.GetSubjectsList();
			System.out.println(resultlist);

			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("Subjects");
			} else {
				mv.addObject("resultlist", resultlist);
				ArrayList<Department> DepartmentList = new ArrayList<>();

				DepartmentList = serviceInt.GetDepartmentList();
				mv.addObject("DepartmentList", DepartmentList);
				mv.setViewName("Subjects");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditSubj.html")
	public ModelAndView SubjectssEdit(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek) throws TTExceptions {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> DepartmentList = new ArrayList<>();
		DepartmentList = serviceInt.GetDepartmentList();
		mv.addObject("deptId", deptId);
		mv.addObject("HourPerPeriod", HourPerPeriod);
		mv.addObject("SubCode", SubCode);
		mv.addObject("SubjectTitle", SubjectTitle);
		mv.addObject("Mode", Mode);
		mv.addObject("Semister", Semister);
		mv.addObject("PeriodPerWeek", PeriodPerWeek);
		mv.addObject("DepartmentList", DepartmentList);
		mv.setViewName("EditSubjects");

		return mv;
	}

	@RequestMapping(value = "/SaveSubj.html")
	public ModelAndView SubjectssSave(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek, @RequestParam String PreviousSubCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		Subject subject = new Subject();
		Department department = new Department();
		department.setDeptId(deptId);
		subject.setDepartment(department);

		subject.setHoursPerPeriod(Integer.parseInt(HourPerPeriod));
		subject.setMode(Mode);
		subject.setPeriodPerWeek(Integer.parseInt(PeriodPerWeek));
		subject.setSemister(Semister);
		subject.setSubCode(SubCode);
		subject.setSubjectTitle(SubjectTitle);
		System.out.println(subject);

		try {
			String result = serviceInt.UpdateSubjectDetails(subject, PreviousSubCode);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use Dept id as in Department Table");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject(subject);
		mv.setViewName("EditSubjects");

		return mv;
	}

	@RequestMapping(value = "/DeleteSubj.html")
	public ModelAndView SubjectssDelete(@RequestParam String SubCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteSubjectsDetails(SubCode);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
		} catch (TTExceptions e) {
		}

		return mv;
	}

	@RequestMapping(value = "/addSubjects.html")
	public ModelAndView SubjectssSave(@RequestParam String deptId, @RequestParam String HourPerPeriod,
			@RequestParam String SubCode, @RequestParam String SubjectTitle, @RequestParam String Mode,
			@RequestParam String Semister, @RequestParam String PeriodPerWeek) {

		ModelAndView mv = new ModelAndView();
		Subject subject = new Subject();
		Department department = new Department();
		department.setDeptId(deptId);
		subject.setDepartment(department);
		subject.setHoursPerPeriod(Integer.parseInt(HourPerPeriod));
		subject.setMode(Mode);
		subject.setPeriodPerWeek(Integer.parseInt(PeriodPerWeek));
		subject.setSemister(Semister);
		subject.setSubCode(SubCode);

		subject.setSubjectTitle(SubjectTitle);

		System.out.println(subject + "in inside the addsubjects method");

		try {
			String result = serviceInt.SaveSubjectsDetails(subject);

			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:SubjectsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use Dept id as in Department Table");
			}
		} catch (TTExceptions e) {
			mv.setViewName("error");
		}
		mv.setViewName("Subjects");
		return mv;
	}

	// Subjects code ends here ---->
	// Designation code ---->

	@RequestMapping(value = "/DesignationsList.html")
	public ModelAndView DesignationsList() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Designation> resultlist = new ArrayList<>();
		try {
			resultlist = serviceInt.GetDesignationList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("designationList");
			} else {
				mv.addObject("resultlist", resultlist);
				mv.setViewName("designationList");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditDesignation.html")
	public ModelAndView DesignationsEdit(@RequestParam String designationCode, @RequestParam String designation) {
		ModelAndView mv = new ModelAndView();

		mv.addObject("designationCode", designationCode);
		mv.addObject("designation", designation);
		mv.setViewName("EditDesignation");

		return mv;
	}

	@RequestMapping(value = "/SaveDesignation.html")
	public ModelAndView DesignationSave(@RequestParam String designationCode, @RequestParam String Designation,
			@RequestParam String PreviousDesignationCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			System.out.println("inside beforee  dat" + designationCode + Designation + PreviousDesignationCode);
			String result = serviceInt.UpdateDesignationDetails(designationCode, Designation, PreviousDesignationCode);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique Designation Code");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("designationCode", designationCode);
		mv.addObject("designation", Designation);
		mv.setViewName("EditDesignation");

		return mv;
	}

	@RequestMapping(value = "/DeleteDesignation.html")
	public ModelAndView DesigantionsDelete(@RequestParam String designationCode) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteDesigantionDetails(designationCode);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addDesignation.html")
	public ModelAndView DesignationsSave(@RequestParam String designationCode, @RequestParam String designation) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveDesignationDetails(designationCode, designation);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:DesignationsList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique usernames");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("designationList");
		return mv;
	}

	// Designation code ends here ---->

	// Faculty code ---->

	@RequestMapping(value = "/FacultysList.html")
	public ModelAndView FacultysList() {
		ModelAndView mv = new ModelAndView();

		ArrayList<Faculty> resultlist = new ArrayList<>();
		try {
			ArrayList<Designation> designationList = new ArrayList<>();
			designationList = serviceInt.GetDesignationList();
			mv.addObject("designationList", designationList);
			ArrayList<Department> departmentlist = new ArrayList<>();
			departmentlist = serviceInt.GetDepartmentList();
			mv.addObject("departmentlist", departmentlist);
			resultlist = serviceInt.GetFacultyList();
			System.out.println(resultlist.toString());
			if (resultlist.isEmpty()) {
				System.out.println(resultlist.isEmpty());
				mv.addObject("message", "No data found");
				mv.setViewName("facultyList");
			} else {

				mv.addObject("resultlist", resultlist);
				mv.setViewName("facultyList");
				if (flag) {
					mv.addObject("message", "successfully changes are stored");
					flag = false;
				}
				if (flag1) {
					mv.addObject("message", "Can't delete the data due to foreign key");
					flag1 = false;
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/EditFaculty.html")
	public ModelAndView FacultysEdit(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek) throws TTExceptions {
		ModelAndView mv = new ModelAndView();

		mv.addObject("facultyId", facultyId);
		mv.addObject("facultyName", facultyName);
		ArrayList<Designation> designationList = new ArrayList<>();
		designationList = serviceInt.GetDesignationList();
		mv.addObject("designationList", designationList);
		ArrayList<Department> departmentlist = new ArrayList<>();
		departmentlist = serviceInt.GetDepartmentList();
		mv.addObject("departmentlist", departmentlist);
		mv.addObject("maxHoursPerDay", maxHoursPerDay);
		mv.addObject("maxHoursPerWeek", maxHoursPerWeek);
		mv.setViewName("EditFaculty");

		return mv;
	}

	@RequestMapping(value = "/SaveFaculty.html")
	public ModelAndView DepartmentsSave(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek, @RequestParam String previousFacultyId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");

		try {
			String result = serviceInt.UpdateFacultyDetails(facultyId, facultyName, deptId, designationCode,
					maxHoursPerDay, maxHoursPerWeek, previousFacultyId);
			System.out.println("after the data");
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "Use unique Faculty ids");
			}

		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		mv.addObject("facultyId", facultyId);
		mv.addObject("facultyName", facultyName);
		mv.addObject("deptId", deptId);
		mv.addObject("designationCode", designationCode);
		mv.addObject("maxHoursPerDay", maxHoursPerDay);
		mv.addObject("maxHoursPerWeek", maxHoursPerWeek);
		mv.setViewName("EditFaculty");

		return mv;
	}

	@RequestMapping(value = "/DeleteFaculty.html")
	public ModelAndView FacultysDelete(@RequestParam String facultyId) {
		ModelAndView mv = new ModelAndView();
		System.out.println("inside controller");
		try {
			String result = serviceInt.DeleteFacultyDetails(facultyId);
			if (result.equals("success")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("Forein key in other Table")) {
				flag1 = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping(value = "/addFaculty.html")
	public ModelAndView FacultysSave(@RequestParam String facultyId, @RequestParam String facultyName,
			@RequestParam String deptId, @RequestParam String designationCode, @RequestParam int maxHoursPerDay,
			@RequestParam int maxHoursPerWeek) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveFacultyDetails(facultyId, facultyName, deptId, designationCode,
					maxHoursPerDay, maxHoursPerWeek);
			System.out.println(result);
			if (result.equals("ADDED successfully")) {
				flag = true;
				return new ModelAndView("redirect:FacultysList.html");
			}
			if (result.equals("unique violation")) {
				mv.addObject("message", "use unique Faculty Id");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("facultyList");
		return mv;
	}

	// department code ends here ---->

	@RequestMapping(value = "/mapping.html")
	public ModelAndView mapping() throws TTExceptions {
		ModelAndView mv = new ModelAndView();
		ArrayList<Faculty> resultlist = new ArrayList<>();
		resultlist = serviceInt.GetFacultyList();
		ArrayList<Subject> resultlist1 = new ArrayList<>();
		resultlist1 = serviceInt.GetSubjectsList();
		mv.addObject("resultlist1", resultlist1);
		mv.addObject("resultlist", resultlist);
		mv.setViewName("mapping");
		return mv;
	}

	@RequestMapping(value = "/SaveMapData.html")
	public ModelAndView mapDataSaving(@RequestParam String facultyid, @RequestParam String[] subcode) {
		ModelAndView mv = new ModelAndView();

		try {
			String result = serviceInt.SaveMapData(facultyid, subcode);
			ArrayList<Faculty> resultlist = new ArrayList<>();
			resultlist = serviceInt.GetFacultyList();
			ArrayList<Subject> resultlist1 = new ArrayList<>();
			resultlist1 = serviceInt.GetSubjectsList();
			mv.addObject("resultlist1", resultlist1);
			mv.addObject("resultlist", resultlist);
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("message", "Successfully mapped the data for the FacultId" + facultyid);
		mv.setViewName("mapping");
		return mv;
	}

	// schedular code
	@RequestMapping(value = "/shedular.html")
	public ModelAndView Schedular() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> DepartmentList = new ArrayList<>();

		try {
			DepartmentList = serviceInt.GetDepartmentList();
			if (flag2) {
				mv.addObject("message", "  No Data found OR Newly added subject or faculty should be mapped ");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("DepartmentList", DepartmentList);
		mv.setViewName("schedular");
		return mv;
	}

	String deptIdGlobal = "";
	String semGlobal = "";

	@RequestMapping(value = "/Getschedular.html")
	public ModelAndView getSchedular(@RequestParam String deptId, @RequestParam String sem) {
		ModelAndView mv = new ModelAndView();
		ArrayList<Subject> SubjectList = new ArrayList<>();

		List<String[]> stringarray = new ArrayList<String[]>();
		try {
			deptIdGlobal = deptId;
			semGlobal = sem;
			SubjectList = serviceInt.GetSubjectsList(deptId, sem);

			HashMap<String, String[]> result1 = serviceInt.GetSchedularDetails(SubjectList);
			System.out.println(result1);
			mv.addObject("result", result1);
			mv.addObject("subjectlist", SubjectList);

			mv.addObject("stringarray", stringarray);
			System.out.println(result1);
			if (result1 == null) {
				flag2 = true;
				return new ModelAndView("redirect:shedular.html");
			}
			if (result1.isEmpty()) {
				flag2 = true;
				return new ModelAndView("redirect:shedular.html");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.setViewName("SchedularList");
		return mv;
	}

	String[][] timetable = new String[6][7];
	String[][] timetable2 = new String[6][7];
	String[][] timetable3 = new String[6][7];
	String[][] timetable4 = new String[6][7];

	@RequestMapping(value = "/saveschedular.html")
	public ModelAndView saveSchedular(@RequestParam String[] subcode, @RequestParam String[] facultyprefered) {
		ModelAndView mv = new ModelAndView();
		ArrayList<Subject> SubjectList = new ArrayList<>();
		ArrayList<Subject> SubjectList2 = new ArrayList<>();
		ArrayList<String[]> schedularSave1 = new ArrayList<>();
		ArrayList<String[]> schedularSave2 = new ArrayList<>();
		ArrayList<String[]> schedularSave3 = new ArrayList<>();
		ArrayList<String[]> schedularSave4 = new ArrayList<>();
		String[] schedularSave = new String[7];
		try {

			schedularSave1=	getSchedularSave(subcode, facultyprefered);
			/*SubjectList = serviceInt.GetSubjectsList(deptIdGlobal, semGlobal);

			for (Subject sub : SubjectList) {
				for (int j = 0; j < subcode.length; j++) {
					if (sub.getSubCode().equals(subcode[j])) {

						for (int i = 0; i < 7;) {

							schedularSave[i] = sub.getSubCode() + " (" + facultyprefered[j] + ")";
							i++;
							schedularSave[i] = sub.getSubjectTitle();
							i++;
							schedularSave[i] = sub.getSemister();
							i++;
							schedularSave[i] = sub.getDepartment().getDeptId();
							i++;
							schedularSave[i] = sub.getMode();
							i++;
							schedularSave[i] = (Integer.toString(sub.getHoursPerPeriod()));
							i++;
							schedularSave[i] = (Integer.toString(sub.getPeriodPerWeek()));
							i++;

							schedularSave1.add(schedularSave);
							schedularSave = new String[7];
						}
					}
				}
			}*/
			/*SubjectList2 = serviceInt.GetSubjectsList(deptIdGlobal, semGlobal);

			for (Subject sub : SubjectList2) {
				for (int j = 0; j < subcode.length; j++) {
					if (sub.getSubCode().equals(subcode[j])) {

						for (int i = 0; i < 7;) {

							schedularSave[i] = sub.getSubCode() + " (" + facultyprefered[j] + ")";
							i++;
							schedularSave[i] = sub.getSubjectTitle();
							i++;
							schedularSave[i] = sub.getSemister();
							i++;
							schedularSave[i] = sub.getDepartment().getDeptId();
							i++;
							schedularSave[i] = sub.getMode();
							i++;
							schedularSave[i] = (Integer.toString(sub.getHoursPerPeriod()));
							i++;
							schedularSave[i] = (Integer.toString(sub.getPeriodPerWeek()));
							i++;

							schedularSave2.add(schedularSave);
							schedularSave = new String[7];
						}
					}
				}
			}
*/
			timetable = getTimeTable(schedularSave1);

			System.out.println("printing tt -1");
			for (int i = 0; i < 7; i++) {
				for (int j = 0; j < 6; j++) {
					if (timetable[j][i] == null) {
						timetable[j][i] = "--";
					}
					System.out.print("       " + timetable[j][i] + "       ");
				}
				System.out.print("\n");
			}
			schedularSave2=	getSchedularSave(subcode, facultyprefered);
			 timetable2 = getTimeTable1(schedularSave2);

			System.out.println("printing section timetable 2");
			for (int i = 0; i < 7; i++) {
				for (int j = 0; j < 6; j++) {
					if (timetable2[j][i] == null) {
						timetable2[j][i] = "--";
					}
					System.out.print("       " + timetable2[j][i] + "       ");
				}
				System.out.print("\n");
			}
			
			String result1 = serviceInt.saveTimeTable(timetable, semGlobal, deptIdGlobal,"section-1");
			String result2 = serviceInt.saveTimeTable(timetable2, semGlobal, deptIdGlobal,"section-2");
			schedularSave3 = getSchedularSave(subcode, facultyprefered);
			 timetable3 = getTimeTable3(schedularSave3);

			System.out.println("printing section timetable 3");
			for (int i = 0; i < 7; i++) {
				for (int j = 0; j < 6; j++) {
					if (timetable3[j][i] == null) {
						timetable3[j][i] = "--";
					}
					System.out.print("       " + timetable3[j][i] + "       ");
				}
				System.out.print("\n");
			}
			
			String result3 = serviceInt.saveTimeTable(timetable, semGlobal, deptIdGlobal,"section-3");
			
		/*schedularSave4=	getSchedularSave(subcode, facultyprefered);
			 timetable4 = getTimeTable4(schedularSave4);

			System.out.println("printing section timetable 2");
			for (int i = 0; i < 7; i++) {
				for (int j = 0; j < 6; j++) {
					if (timetable4[j][i] == null) {
						timetable4[j][i] = "--";
					}
					System.out.print("       " + timetable4[j][i] + "       ");
				}
				System.out.print("\n");
			}
			
			String result4 = serviceInt.saveTimeTable(timetable, semGlobal, deptIdGlobal,"section-4");*/
			
			
			
			if (result1.equals("ADDED successfully") && result2.equals("ADDED successfully") && result3.equals("ADDED successfully") /*&& result4.equals("ADDED successfully") */ ) {
				mv.addObject("message",
						"Timetable generated successfully please click on view timetables to display timetable ");
			}
			if (result1.equals("unique violation") && result2.equals("unique violation") && result3.equals("unique violation") /*&& result4.equals("unique violation")*/  ) {
				mv.addObject("message", "use unique data");
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			mv.addObject("message", "Cannot generate time table please see logs ");
		}
		mv.setViewName("LoginSuccess");
		return mv;
	}

	private String[][] getTimeTable3(ArrayList<String[]> schedularSave3) {
		x=1;
		String[][] timetable21 = new String[6][7];
		int p = 0;
		int urandom = 0;
		String[] sub = new String[7];
		Random rand = new Random();
		for (int r = 0; r < 20000; r++) {
			int randNumber = rand.nextInt(schedularSave3.size() - 1);
			sub = schedularSave3.get(randNumber);

			if (urandom > 55000) {
				break;
			}

			while (Integer.parseInt((sub[6])) > 0) {
				if (urandom > 55000) {
					break;
				}

				if (urandom < 55000) {

					int w = rand.nextInt(6);

					if (Integer.parseInt((sub[5])) == 1) {
						p = rand.nextInt(7);
						int f = rand.nextInt(4);

						if (timetable21[w][f] == null) {

							if (!sub[0].contains(timetable[w][f]) && !sub[0].contains(timetable2[w][f]) ) {

								timetable21[w][f] = sub[0];

								sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));
							}
						}

					} else {
						if (timetable21[w][4] == null) {

							if (!sub[0].contains(timetable[w][4]) && !sub[0].contains(timetable2[w][4]) ) {
								{

									timetable21[w][4] = sub[0];
									timetable21[w][5] = sub[0];
									timetable21[w][6] = sub[0];

									sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));

								}
							} else {
								break;

							}
						}
					}

					urandom++;

				}

			}
			schedularSave3.remove(randNumber);
			schedularSave3.add(sub);
		}
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {

				System.out.print("       " + timetable21[j][i] + "       ");
			}
			System.out.print("\n");
		}
		System.out.println("inside third section last");
		// gaps in first 4 periods null vlues filling
		for (String[] arraylist : schedularSave3) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable21[j][i] == null) {
							if (i == 0 || i == 1 || i == 2 || i == 3) {
								if (!sub[0].contains(timetable[j][i]) && !sub[0].contains(timetable2[j][i]) ) {
									timetable21[j][i] = arraylist[0];
									arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
								}
							}
						}
					}

				}
			}
		}
		// gaps in last 3 periods null vlues filling
		for (String[] arraylist : schedularSave3) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("3")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable21[j][4] == null) {
							if (!arraylist[0].contains(timetable[j][4]) && !arraylist[0].contains(timetable2[j][4])) {
								System.out.println(arraylist[0] + "is selected subject");
								timetable21[j][4] = arraylist[0];
								timetable21[j][5] = arraylist[0];
								timetable21[j][6] = arraylist[0];
								arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
							}
						}
					}

				}
			}
		}
		// filling if any null values again as random
		// filling if any null values again as random
		for (String[] arraylist1 : schedularSave3) {
			if (arraylist1[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable21[j][i] == null) {

							if (j != 0 && (i == 0 || i == 1 || i == 2 || i == 3)) {
								if (!arraylist1[0].contains(timetable[j][i]) && !arraylist1[0].contains(timetable2[j][i])) {
									timetable21[j][i] = timetable21[j - 1][i];
								}
							} else {

								while (x == 1 || timetable21[j][i] == null) {
									
									x = 2;
									int randNumber = rand.nextInt(schedularSave3.size() - 1);
									sub = schedularSave3.get(randNumber);
									if (Integer.parseInt((sub[5])) == 1) {

										if (!sub[0].contains(timetable[j][i]) && !sub[0].contains(timetable2[j][i])) {
											
											timetable21[j][i] = sub[0];
										}
									}

								}

							}
						}
					}

				}
			}
		}

		return timetable21;

	}


	private String[][] getTimeTable4(ArrayList<String[]> schedularSave4) {
		x=1;
		String[][] timetable41 = new String[6][7];
		int p = 0;
		int urandom = 0;
		String[] sub = new String[7];
		Random rand = new Random();
		for (int r = 0; r < 20000; r++) {
			int randNumber = rand.nextInt(schedularSave4.size() - 1);
			sub = schedularSave4.get(randNumber);

			if (urandom > 55000) {
				break;
			}

			while (Integer.parseInt((sub[6])) > 0) {
				if (urandom > 55000) {
					break;
				}

				if (urandom < 55000) {

					int w = rand.nextInt(6);

					if (Integer.parseInt((sub[5])) == 1) {
						p = rand.nextInt(7);
						int f = rand.nextInt(4);

						if (timetable41[w][f] == null) {

							if (!sub[0].contains(timetable[w][f]) && !sub[0].contains(timetable2[w][f]) && !sub[0].contains(timetable3[w][f]) ) {

								timetable41[w][f] = sub[0];

								sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));
							}
						}

					} else {
						if (timetable41[w][4] == null) {

							if (!sub[0].contains(timetable[w][4]) && !sub[0].contains(timetable2[w][4]) && !sub[0].contains(timetable3[w][4]) ) {
								{

									timetable41[w][4] = sub[0];
									timetable41[w][5] = sub[0];
									timetable41[w][6] = sub[0];

									sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));

								}
							} else {
								break;

							}
						}
					}

					urandom++;

				}

			}
			schedularSave4.remove(randNumber);
			schedularSave4.add(sub);
		}
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {

				System.out.print("       " + timetable41[j][i] + "       ");
			}
			System.out.print("\n");
		}
		System.out.println("inside third section last");
		// gaps in first 4 periods null vlues filling
		for (String[] arraylist : schedularSave4) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable41[j][i] == null) {
							if (i == 0 || i == 1 || i == 2 || i == 3) {
								if (!sub[0].contains(timetable[j][i]) && !sub[0].contains(timetable2[j][i])  && !sub[0].contains(timetable3[j][i]) ) {
									timetable41[j][i] = arraylist[0];
									arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
								}
							}
						}
					}

				}
			}
		}
		// gaps in last 3 periods null vlues filling
		for (String[] arraylist : schedularSave4) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("3")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable41[j][4] == null) {
							if (!arraylist[0].contains(timetable[j][4]) && !arraylist[0].contains(timetable2[j][4]) &&  !arraylist[0].contains(timetable3[j][4])) {
								System.out.println(arraylist[0] + "is selected subject");
								timetable41[j][4] = arraylist[0];
								timetable41[j][5] = arraylist[0];
								timetable41[j][6] = arraylist[0];
								arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
							}
						}
					}

				}
			}
		}
		// filling if any null values again as random
		// filling if any null values again as random
		for (String[] arraylist1 : schedularSave4) {
			if (arraylist1[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable41[j][i] == null) {

							if (j != 0 && (i == 0 || i == 1 || i == 2 || i == 3)) {
								if (!arraylist1[0].contains(timetable[j][i]) && !arraylist1[0].contains(timetable2[j][i]) && !arraylist1[0].contains(timetable3[j][i])) {
									timetable41[j][i] = timetable41[j - 1][i];
								}
							} else {

								while (x == 1 || timetable41[j][i] == null) {
									
									x = 2;
									int randNumber = rand.nextInt(schedularSave4.size() - 1);
									sub = schedularSave4.get(randNumber);
									if (Integer.parseInt((sub[5])) == 1) {

										if (!sub[0].contains(timetable[j][i]) && !sub[0].contains(timetable2[j][i])  && !sub[0].contains(timetable3[j][i])) {
											
											timetable41[j][i] = sub[0];
										}
									}

								}

							}
						}
					}

				}
			}
		}

		return timetable41;

	}



	private ArrayList<String[]> getSchedularSave(String[] subcode, String[] facultyprefered) {
		ArrayList<Subject> SubjectList = new ArrayList<>();

		ArrayList<String[]> schedularSave1 = new ArrayList<>();
		String[] schedularSave = new String[7];

		try {
			SubjectList = serviceInt.GetSubjectsList(deptIdGlobal, semGlobal);

			for (Subject sub : SubjectList) {
				for (int j = 0; j < subcode.length; j++) {
					if (sub.getSubCode().equals(subcode[j])) {

						for (int i = 0; i < 7;) {

							schedularSave[i] = sub.getSubCode() + " (" + facultyprefered[j] + ")";
							i++;
							schedularSave[i] = sub.getSubjectTitle();
							i++;
							schedularSave[i] = sub.getSemister();
							i++;
							schedularSave[i] = sub.getDepartment().getDeptId();
							i++;
							schedularSave[i] = sub.getMode();
							i++;
							schedularSave[i] = (Integer.toString(sub.getHoursPerPeriod()));
							i++;
							schedularSave[i] = (Integer.toString(sub.getPeriodPerWeek()));
							i++;

							schedularSave1.add(schedularSave);
							schedularSave = new String[7];
						}
					}
				}
			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return schedularSave1;

	}

	private String[][] getTimeTable(ArrayList<String[]> schedularSave1) {
		String[][] timetable = new String[6][7];
		int p = 0;
		int u = 0;
		String[] sub = new String[7];
		Random rand = new Random();
		for (int r = 0; r < 20000; r++) {

			int randNumber = rand.nextInt(schedularSave1.size() - 1);
			sub = schedularSave1.get(randNumber);

			if (u > 55000) {
				break;
			}

			while (Integer.parseInt((sub[6])) > 0) {
				if (u > 55000) {
					break;
				}
				if (u < 55000) {
					int w = rand.nextInt(6);

					if (Integer.parseInt((sub[5])) == 1) {
						p = rand.nextInt(7);
						int f = rand.nextInt(4);

						if (timetable[w][f] == null) {
							timetable[w][f] = sub[0];

							sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));
						}

					} else {
						if (timetable[w][4] == null)// check

						{
							timetable[w][4] = sub[0];
							timetable[w][5] = sub[0];
							timetable[w][6] = sub[0];

							sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));

						} else {
							break;

						}
					}

					u++;
					/* System.out.println("u value is " + u); */
				}

			}
			schedularSave1.remove(randNumber);
			schedularSave1.add(sub);
		}
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {

				System.out.print("       " + timetable[j][i] + "       ");
			}
			System.out.print("\n");
		}

		/*
		 * for (String[] arraylist : schedularSave1) {
		 * System.out.println("subject code" + arraylist[0]);
		 * System.out.println("remaining data" + arraylist[6]);
		 * 
		 * }
		 */
		// gaps in first 4 periods null vlues filling
		for (String[] arraylist : schedularSave1) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable[j][i] == null) {
							if (i == 0 || i == 1 || i == 2 || i == 3) {
								timetable[j][i] = arraylist[0];
								arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
							}
						}
					}

				}
			}
		}
		// gaps in last 3 periods null vlues filling
		for (String[] arraylist : schedularSave1) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("3")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable[j][4] == null) {
							System.out.println(arraylist[0] + "is selected subject");
							timetable[j][4] = arraylist[0];
							timetable[j][5] = arraylist[0];
							timetable[j][6] = arraylist[0];
							arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);

						}
					}

				}
			}
		}
		// filling if any null values again as random
		for (String[] arraylist1 : schedularSave1) {
			if (arraylist1[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable[j][i] == null) {
							if (j != 0 && (i == 0 || i == 1 || i == 2 || i == 3))
								timetable[j][i] = timetable[j - 1][i];
							else {
								int randNumber = rand.nextInt(schedularSave1.size() - 1);
								sub = schedularSave1.get(randNumber);
								if (Integer.parseInt((sub[5])) == 1) {
									timetable[j][i] = sub[0];
								}
							}

						}
					}

				}
			}
		}

		return timetable;

	}

	@SuppressWarnings("unused")
	private String[][] getTimeTable1(ArrayList<String[]> schedularSave1) {
		String[][] timetable2 = new String[6][7];
		int p = 0;
		int urandom = 0;
		String[] sub = new String[7];
		Random rand = new Random();
		for (int r = 0; r < 20000; r++) {
			int randNumber = rand.nextInt(schedularSave1.size() - 1);
			sub = schedularSave1.get(randNumber);

			if (urandom > 55000) {
				break;
			}

			while (Integer.parseInt((sub[6])) > 0) {
				if (urandom > 55000) {
					break;
				}

				if (urandom < 55000) {

					int w = rand.nextInt(6);

					if (Integer.parseInt((sub[5])) == 1) {
						p = rand.nextInt(7);
						int f = rand.nextInt(4);

						if (timetable2[w][f] == null) {

							if (!sub[0].contains(timetable[w][f])) {

								timetable2[w][f] = sub[0];

								sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));
							}
						}

					} else {
						if (timetable2[w][4] == null) {

							if (!sub[0].contains(timetable[w][4])) {
								{

									timetable2[w][4] = sub[0];
									timetable2[w][5] = sub[0];
									timetable2[w][6] = sub[0];

									sub[6] = Integer.toString((Integer.parseInt((sub[6])) - 1));

								}
							} else {
								break;

							}
						}
					}

					urandom++;

				}

			}
			schedularSave1.remove(randNumber);
			schedularSave1.add(sub);
		}
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 6; j++) {

				System.out.print("       " + timetable2[j][i] + "       ");
			}
			System.out.print("\n");
		}

		// gaps in first 4 periods null vlues filling
		for (String[] arraylist : schedularSave1) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable2[j][i] == null) {
							if (i == 0 || i == 1 || i == 2 || i == 3) {
								if (!sub[0].contains(timetable[j][i])) {
									timetable2[j][i] = arraylist[0];
									arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
								}
							}
						}
					}

				}
			}
		}
		// gaps in last 3 periods null vlues filling
		for (String[] arraylist : schedularSave1) {
			if (!arraylist[6].equals("0") && arraylist[5].equals("3")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable2[j][4] == null) {
							if (!arraylist[0].contains(timetable[j][4])) {
								System.out.println(arraylist[0] + "is selected subject");
								timetable2[j][4] = arraylist[0];
								timetable2[j][5] = arraylist[0];
								timetable2[j][6] = arraylist[0];
								arraylist[6] = Integer.toString(Integer.parseInt(arraylist[6]) - 1);
							}
						}
					}

				}
			}
		}
		// filling if any null values again as random
		for (String[] arraylist1 : schedularSave1) {
			if (arraylist1[5].equals("1")) {
				for (int i = 0; i < 7; i++) {
					for (int j = 0; j < 6; j++) {
						if (timetable2[j][i] == null) {

							if (j != 0 && (i == 0 || i == 1 || i == 2 || i == 3)) {
								if (!arraylist1[0].contains(timetable[j][i])) {
									timetable2[j][i] = timetable2[j - 1][i];
								}
							} else {

								while (x == 1 || timetable2[j][i] == null) {
									
									x = 2;
									int randNumber = rand.nextInt(schedularSave1.size() - 1);
									sub = schedularSave1.get(randNumber);
									if (Integer.parseInt((sub[5])) == 1) {

										if (!sub[0].contains(timetable[j][i])) {
											
											timetable2[j][i] = sub[0];
										}
									}

								}

							}
						}
					}

				}
			}
		}

		return timetable2;

	}

	@RequestMapping(value = "/timetable.html")
	public ModelAndView timetable() {
		ModelAndView mv = new ModelAndView();
		ArrayList<Department> DepartmentList = new ArrayList<>();

		try {
			DepartmentList = serviceInt.GetDepartmentList();
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mv.addObject("DepartmentList", DepartmentList);

		mv.setViewName("viewTimeTable");
		return mv;
	}

	@RequestMapping(value = "/getTimetable.html")
	public ModelAndView getTimeTable(@RequestParam String sem, @RequestParam String deptId,@RequestParam String section) {
		ModelAndView mv = new ModelAndView();
		ArrayList<TimeTable> tt = new ArrayList<>();
		try {

			tt = serviceInt.GetTimeTable(sem, deptId,section);
			if (tt.isEmpty()) {
				System.out.println(tt.isEmpty());
				ArrayList<Department> DepartmentList = new ArrayList<>();
				DepartmentList = serviceInt.GetDepartmentList();
				mv.addObject("DepartmentList", DepartmentList);
				mv.addObject("message", "No data found");
				mv.setViewName("viewTimeTable");
			} else {

				mv.addObject("resultlist", tt);
				mv.setViewName("getTimeTable");

			}
		} catch (TTExceptions e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mv.addObject("message", " uncaught exception contact admin");
			mv.setViewName("viewTimeTable");
		}

		return mv;
	}

	@RequestMapping(value = "/Logout.html")
	public ModelAndView logout(HttpSession session) {
    	
        session.invalidate();
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("message", "Succesfully logged out ");
		mv.setViewName("Logout");
		return mv;
	}
	@RequestMapping(value = "/index.html")
	public ModelAndView index() throws TTExceptions {
		ModelAndView mv = new ModelAndView();
		
		
		mv.setViewName("index");
		return mv;
	}

}